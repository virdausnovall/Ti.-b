from app import db


class mata_kuliah(db.Model):
    kode = db.Column(db.Integer, primary_key=True, nullable=False)
    nama_dosen = db.Column(db.String(50), nullable=False)

class dosen(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    nip = db.Column(db.String(50), nullable=False)
    nama = db.Column(db.String(100), nullable=False)
    jenis_kelamin = db.Column(db.String(100), nullable=False)